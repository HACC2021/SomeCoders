﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using System;

using Twilio;
using Twilio.Rest.Api.V2010.Account;

using Twilio.Types;

using Twilio.TwiML;
using Twilio.AspNet.Mvc;
using PetPickupSolution.Models;

namespace PetPickupSolution.Controllers
{
    public class SMSController : Controller
    {

        //auth error here... think it has to do with a new authToken being generated... unable to send messages
        [HttpPost]
        public void SendSMS(PetPickupModel petPickup)
        {
            //commenting out for now but before site is launched this needs to be implemented for security
            //var accountSID = Environment.GetEnvironmentVariable("TWILIO_ACCOUNT_SID");
            //var authToken = Environment.GetEnvironmentVariable("TWILIO_AUTH_TOKEN");

            var accountSID = "ACb3e690d2ed4b17436d984e0225c16094";
            var authToken = "48cb22c64f90bd1474ec96ac37f95dc3";

            TwilioClient.Init(accountSID, authToken);

            var message = MessageResource.Create(
                body: petPickup.PetName + " is ready to be picked up!",
                from: new Twilio.Types.PhoneNumber("+18082013388"),
                to: new Twilio.Types.PhoneNumber(petPickup.OwnerPhoneNumber)
            );

            Console.WriteLine(message.Sid);
        }

        [HttpPost]
        public TwiMLResult MessageResponse()
        {
            var messagingResponse = new MessagingResponse();
            messagingResponse.Message("Your message has been recieved! Your phone number has been account to the your pet and you will recieve a text message when your pet" +
                "is ready to be picked up.");

            return TwiML(messagingResponse);
        }

        //not sure if generating this method will fix the above method
        private TwiMLResult TwiML(MessagingResponse messagingResponse)
        {
            throw new NotImplementedException();
        }
        

    }
}
